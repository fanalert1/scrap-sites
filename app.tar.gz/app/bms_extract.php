<?php
require_once('../vendor/autoload.php');
require_once('imdb_get.php');
require_once('config/db.php');
require('global_function.php');


date_default_timezone_set("Asia/Calcutta");//Set timezone to India
$current_ts=date("Y/m/d H:i:s");
echo "Job Started on ".$current_ts."\n";

use Goutte\Client;
use Symfony\Component\DomCrawler\Crawler;


$bms_url='https://in.bookmyshow.com/chennai/movies/nowshowing';

if(linkcheck($bms_url))
{
    $client = new Client();
	$crawler = $client->request('GET', $bms_url);
	$upcoming_movies=array();
	$i=0;
	$j=0;
	$crawler->filter('#now-showing > section.now-showing.filter-now-showing > div > div.__col-now-showing')->each(function (Crawler $node, $i) {
	    $node->filter('div.detail')->each(function (Crawler $node, $i) {
	        global $i,$j;
	           $node->filter('div.__name > a')->each(function ($node)
	               {
	                   global $i;
	                   global $upcoming_movies;
	                    $upcoming_movies[$i]["name"] = $node->text();
	                    
	                    $link = $node->attr('href');
	                    $upcoming_movies[$i]["link"] = "https://in.bookmyshow.com".$link;
	                });
	            $node->filter('div.languages > ul > li')->each(function ($node)
	               {
	                   global $i,$j;
	                    global $upcoming_movies;
	                    $upcoming_movies[$i]["lang"][$j] = $node->text();
	                    $j+=1;
	                });
	        $i +=1;
	        $j=0;
	    });
    
	});
	
	
foreach($upcoming_movies as $movies)
{
    $movie_name = $movies["name"];
    $movie_link = $movies["link"];
    print_r($movies["lang"]);
    
    foreach ($movies["lang"] as $lang) 
    
    {
   			//echo "$value <br>";

    		$lang=trim($lang);
    		$lang=str_replace(',','',$lang); //fix for comma coming along with lang issue
    		
	        $present=isPresent($movie_name,$movies_collection,$lang);
		     if($present!="")
            {
                $movie_id=$present;
		        $movie=getDetail($movie_id,$movies_collection,"_id","type");
               	$current_type=$movie["type"];
                $prevs_type=$movie["prev_type"];
				$type="running";
				if($current_type=="upcoming")
				{
					$result = $movies_collection->updateOne(
					['_id' => $movie_id],
					['$set' => array("lang"=>$movies["lang"],"type" => $type, "prev_type" => "upcoming", "update_ts" => $current_ts )],
					['upsert' => false]
					);
					
					if(!checkLink($movie,$movie_link))
					$result = $movies_collection->updateOne(
			        		   	['_id' => $movie_id],
			        		    ['$addToSet' => array("source"=> array("bms" => array("title"=>$movie_name,"link"=>$movie_link,"booking_open_ts"=>$current_ts)))],
			        		    ['upsert' => false]);
			        		    
					$events = $events_collection->insertOne(
					array("movie_name"=>$movie_name,"lang"=>$lang,"event_id"=>getCounter("event_id",$counter_collection),"event_type" => "UR","notify"=> 'true',"insert_ts" => $current_ts ));
				}
				elseif($current_type=="running")
				{
					$result = $movies_collection->updateOne(
						['_id' => $movie_id],
						['$set' => array("type" => $type, "update_ts" => $current_ts )],
						['upsert' => false]);
					
					if(!checkLink($movie,$movie_link))	
					$result = $movies_collection->updateOne(
			        		  	['_id' => $movie_id],
			        		    ['$addToSet' => array("source"=> array("bms" => array("title"=>$movie_name,"link"=>$movie_link,"booking_open_ts"=>$current_ts)))],
			        		    ['upsert' => false]);
				}
				elseif($current_type=="closed")
				{
					$result = $movies_collection->updateOne(
						['_id' => $movie_id],
						['$set' => array( "type" => $type,"prev_type" => "closed", "update_ts" => $current_ts )],
						['upsert' => false]);
						
					if(!checkLink($movie,$movie_link))
					$result = $movies_collection->updateOne(
			        		   	['_id' => $movie_id],
			        		    ['$addToSet' => array("source"=> array("bms" => array("title"=>$movie_name,"link"=>$movie_link,"booking_open_ts"=>$current_ts)))],
			        		    ['upsert' => false]);
				}        
		    }else {
		        
		        $movie_details=get_imdb_det($movies["name"]);
		        if(is_array($movie_details)&&(count($movie_details)==1))
		        {
		            foreach($movie_details as $details)
		            {
		                $result = $movies_collection->insertOne(
				    	array("name" => $movie_name,"search_string" => getSearchString($movie_name), "lang" => $lang, "type" => "running", "prev_type"=>"null","det_stat"=>"new", "poster_url"=>$details["poster"],"actors"=>$details["cast"],"director"=>$details["director"],"music_director"=>$details["music"],"genre"=>$details["genre"],"producer"=>$details["producer"],"release_ts"=>$details["release"], "disabled"=>"false", "insert_ts" => $current_ts ));
				    	
				    	$result = $movies_collection->updateOne(
			        		    ['name' => $movie_name, 'lang' => $lang],
			        		    ['$addToSet' => array("source"=> array("bms" => array("title"=>$movie_name,"link"=>$movie_link,"booking_open_ts"=>$current_ts)))],
			        		    ['upsert' => false]);
			            
				    	$events = $events_collection->insertOne(
				    	array("movie_name"=>$movie_name, "lang" => $lang,"event_id"=>getCounter("event_id",$counter_collection),"event_type" => "FR","notify"=> 'true',"insert_ts" => $current_ts ));
			            
		            }
		        }
		        else 
		        {
		            $result = $movies_collection->insertOne(
				    	array("name" => $movie_name,"search_string" => getSearchString($movie_name), "lang" => $lang, "type" => "running", "prev_type"=>"null","det_stat"=>"new","disabled"=>"false", "insert_ts" => $current_ts ));
				    	
				    $result = $movies_collection->updateOne(
			        	    ['name' => $movie_name, 'lang' => $lang],
			        	    ['$addToSet' => array("source"=> array("bms" => array("title"=>$movie_name,"link"=>$movie_link,"booking_open_ts"=>$current_ts)))],
			        	    ['upsert' => false]);
			            
				    $events = $events_collection->insertOne(
				    	array("movie_name"=>$movie_name, "lang"=>$lang, "event_id"=>getCounter("event_id",$counter_collection),"event_type" => "FR","notify"=> 'true',"insert_ts" => $current_ts ));
			            
		        }
		        
		    }
	    
    }
}
}
$current_ts=date("Y/m/d H:i:s");
echo "Job completed on ".$current_ts."\n";
?>