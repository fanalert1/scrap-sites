<?php

/*
*This PHP script will scrape the MovieCrow website for movie database.
*/

require_once('../vendor/autoload.php');
require_once('imdb_get.php');
require_once('config/db.php');
require('global_function.php');

date_default_timezone_set("Asia/Calcutta");
$current_ts=date("Y/m/d H:i:s");
echo "Job Started on ".$current_ts."\n";

use Browser\Casper;
use Goutte\Client;
use Symfony\Component\DomCrawler\Crawler;

$client = new Client();
$crawler = $client->request('GET', 'http://www.moviecrow.com/tamil/new-movies');

$movies_list=array();
$movie_key="";

$crawler->filter('#rank-tab-10')->each(function (Crawler $node, $i) {
             
            $node->filter('div.releasing_in')->each(function (Crawler $node, $i) {
                 
                        $node->filter('span.movieTitle')->each(function ($node) {
                             global $movie_key;
                             $movie_key=$node->text();
                             //echo $movie_key."\n";
                        });
                        $node->filter('span.movieDirector')->each(function ($node) {
                             global $movies_list;
                             global $movie_key;
                             $movies_list[$movie_key]["director"]=$node->text();
                        });
                        $node->filter('span.movieCast')->each(function ($node) {
                             global $movies_list;
                             global $movie_key;
                             $movies_list[$movie_key]["cast"]=$node->text();
                        });
                        $node->filter('span.movieMusicDirector')->each(function ($node) {
                             global $movies_list;
                             global $movie_key;
                             $movies_list[$movie_key]["music"]=$node->text();
                        });
                        $node->filter('span.movieImageLink')->each(function ($node) {
                             global $movies_list;
                             global $movie_key;
                             $movies_list[$movie_key]["link"]=$node->text();
                        });
                        $node->filter('a.btn-play-t')->each(function ($node) {
                             global $movies_list;
                             global $movie_key;
                             global $client;
                             $link = $node->attr('href');
                             $crawler = $client->request('GET', $link);
                             $crawler->filter('iframe')->each(function ($node) {
                                global $movies_list;
                                global $movie_key;
                                $movies_list[$movie_key]["trailer"]=$node->attr('src');
                             });
                        });
                         
             
                         
             });
});

$current_ts=date("Y/m/d H:i:s");
foreach($movies_list as $key=>$values)
{
    print_r($values);
    $movie_name=$key; //sets language as key of the array
    $lang="Tamil";
    $present=isPresent($movie_name,$movies_collection,$lang);
    if($present=="")
    {
        $movie_details=get_imdb_det($movie_name);
        if(is_array($movie_details)&&(count($movie_details)==1))
        {
            foreach($movie_details as $details)
            {
                $result = $movies_collection->insertOne(
	           	array("name" => $movie_name,"search_string" => getSearchString($movie_name), "lang" => $lang, "type" => "new", "prev_type"=>"null","det_stat"=>"new","poster_url"=>$details["poster"],"actors"=>$details["cast"],"director"=>$details["director"],"music_director"=>$details["music"],"genre"=>$details["genre"],"producer"=>$details["producer"],"release_ts"=>$details["release"], "det_stat"=>"new","disabled"=>"false", "insert_ts" => $current_ts ));
	           	
            }
        }
        else 
        {
            $result = $movies_collection->insertOne(
	        array("name" => $movie_name,"search_string" => getSearchString($movie_name), "lang" => $lang, "type" => "new", "prev_type"=>"null","det_stat"=>"new","disabled"=>"false", "insert_ts" => $current_ts ));
        }
    }
    
}

$current_ts=date("Y/m/d H:i:s");
echo "Job completed on ".$current_ts."\n";
?>
