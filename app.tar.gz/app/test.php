<?php

require_once('../vendor/autoload.php');
require_once('imdb_get.php');
require_once('config/db.php');
require('global_function.php');

     
     $value = "Pichaikaran";
     $lang = "Tamil";
     $present=isPresent($value,$movies_collection,$lang);
     if ($present!="")
     {
     echo $present;
   //  $realmongoid = new MongoId($mongoid);
     $movie = $movies_collection->findOne(['_id' => $present]);
     //print_r( $movie);
    // print_r($movie["source"][1]["tktnew"]);
     
     
     
          foreach($movie["source"] as $source) 
          {
               foreach($source as $key=>$value)
               
               {
                    //echo $key;
                    //print_r($value);
                    echo $value["link"];
                    
               }
               //print_r($source["tktnew"]["link"]);
          }
     }
     else
     echo "not found";
?>